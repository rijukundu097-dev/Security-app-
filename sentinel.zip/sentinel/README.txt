Sentinel - Module 1 (skeleton)
1. Put ALL files in a new GitHub repo, keeping the folder structure.
2. Push to main -> Actions tab -> "Build APK" -> download artifact "Sentinel-debug-apk".
3. Unzip the artifact, install app-debug.apk.
