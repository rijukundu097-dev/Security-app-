package com.riju.sentinel.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0A1628)
val NavyCard = Color(0xFF12223B)
val SafeGreen = Color(0xFF2ECC71)
val ThreatRed = Color(0xFFE74C3C)
val WarnAmber = Color(0xFFF1C40F)
val AccentBlue = Color(0xFF3D8BFF)
val TextDim = Color(0xFF9FB0C9)

@Composable
fun SentinelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = AccentBlue, background = Navy, surface = NavyCard,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}
