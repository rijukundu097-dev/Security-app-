package com.riju.sentinel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.riju.sentinel.data.AppDb
import java.text.DateFormat
import java.util.Date

@Composable
fun Placeholder(title: String, note: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(note, color = TextDim)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(NavyCard, RoundedCornerShape(16.dp)).padding(16.dp)) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = TextDim, fontSize = 12.sp)
    }
}

@Composable
fun HomeScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).scanDao() }
    val last by dao.observeLatest().collectAsState(initial = null)
    val totalFiles by dao.observeTotalFiles().collectAsState(initial = 0)

    // Status comes only from real scan records. No scan yet = honest "not scanned".
    val l = last
    val (status, color) = when {
        l == null -> "No scan yet" to WarnAmber
        l.threats > 0 -> "Threats found" to ThreatRed
        l.suspicious > 0 -> "Needs attention" to WarnAmber
        else -> "No threats found in last scan" to SafeGreen
    }
    val lastText = l?.let { DateFormat.getDateTimeInstance().format(Date(it.timestamp)) } ?: "Never"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Sentinel", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Column(
            Modifier.fillMaxWidth().background(NavyCard, RoundedCornerShape(24.dp)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ShieldLogo(color)
            Spacer(Modifier.height(12.dp))
            Text(status, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = color)
            Text("Last scan: $lastText", color = TextDim, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { go("scan") }, colors = ButtonDefaults.buttonColors(containerColor = SafeGreen)) {
                Text("Quick Scan", color = Navy)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Files scanned", totalFiles.toString(), Modifier.weight(1f))
            StatCard("Threats", (l?.threats ?: 0).toString(), Modifier.weight(1f))
            StatCard("Suspicious", (l?.suspicious ?: 0).toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { go("apps") }, Modifier.weight(1f)) { Text("App Scanner") }
            OutlinedButton(onClick = { go("tools") }, Modifier.weight(1f)) { Text("Website Checker") }
        }
    }
}
