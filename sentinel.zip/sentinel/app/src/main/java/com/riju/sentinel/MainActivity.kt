package com.riju.sentinel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.*
import androidx.navigation.NavGraph.Companion.findStartDestination
import com.riju.sentinel.ui.*

private data class Tab(val route: String, val label: String, val icon: ImageVector)
private val tabs = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("scan", "Scan", Icons.Filled.Search),
    Tab("apps", "Apps", Icons.Filled.Apps),
    Tab("privacy", "Privacy", Icons.Filled.Lock),
    Tab("tools", "Tools", Icons.Filled.Build),
    Tab("settings", "Settings", Icons.Filled.Settings),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SentinelTheme { SentinelApp() } }
    }
}

@Composable
fun SentinelApp() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    val go: (String) -> Unit = { r ->
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true; restoreState = true
        }
    }
    Scaffold(
        containerColor = Navy,
        bottomBar = {
            NavigationBar(containerColor = NavyCard) {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = current == t.route,
                        onClick = { go(t.route) },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SafeGreen, selectedTextColor = SafeGreen,
                            indicatorColor = Navy, unselectedIconColor = TextDim, unselectedTextColor = TextDim)
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(go) }
            composable("scan") { Placeholder("Scan", "Quick, Full and Custom scans arrive in Module 3.") }
            composable("apps") { Placeholder("Apps", "Installed-app permission analysis arrives in Module 2.") }
            composable("privacy") { Placeholder("Privacy", "Permission dashboard arrives in Module 5.") }
            composable("tools") { Placeholder("Tools", "Hash, URL and password checkers arrive in later modules.") }
            composable("settings") { Placeholder("Settings", "Notifications, scheduling and API key settings arrive in later modules.") }
        }
    }
}
