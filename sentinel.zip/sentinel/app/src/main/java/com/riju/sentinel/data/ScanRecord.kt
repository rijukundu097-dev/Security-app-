package com.riju.sentinel.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "scan_records")
data class ScanRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val type: String,          // QUICK, FULL, CUSTOM
    val filesChecked: Int,
    val appsAssessed: Int,
    val threats: Int,
    val suspicious: Int,
    val durationMs: Long
)

@Dao
interface ScanDao {
    @Insert suspend fun insert(record: ScanRecord): Long
    @Query("SELECT * FROM scan_records ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<ScanRecord>>
    @Query("SELECT * FROM scan_records ORDER BY timestamp DESC LIMIT 1")
    fun observeLatest(): Flow<ScanRecord?>
    @Query("SELECT COALESCE(SUM(filesChecked),0) FROM scan_records")
    fun observeTotalFiles(): Flow<Int>
}

@Database(entities = [ScanRecord::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun scanDao(): ScanDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: android.content.Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "sentinel.db")
                .build().also { inst = it }
        }
    }
}
