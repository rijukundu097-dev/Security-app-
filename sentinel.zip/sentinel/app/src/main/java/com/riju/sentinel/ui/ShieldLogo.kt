package com.riju.sentinel.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun ShieldLogo(color: Color, size: Dp = 120.dp, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "pulse")
    val glow by t.animateFloat(0.15f, 0.45f,
        infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val p = Path().apply {
            moveTo(w * 0.5f, h * 0.04f)
            lineTo(w * 0.92f, h * 0.2f)
            lineTo(w * 0.92f, h * 0.5f)
            cubicTo(w * 0.92f, h * 0.78f, w * 0.7f, h * 0.92f, w * 0.5f, h * 0.98f)
            cubicTo(w * 0.3f, h * 0.92f, w * 0.08f, h * 0.78f, w * 0.08f, h * 0.5f)
            lineTo(w * 0.08f, h * 0.2f)
            close()
        }
        drawPath(p, color.copy(alpha = glow))
        drawPath(p, color, style = Stroke(width = w * 0.05f, join = StrokeJoin.Round))
        val c = Path().apply {
            moveTo(w * 0.3f, h * 0.5f); lineTo(w * 0.45f, h * 0.65f); lineTo(w * 0.72f, h * 0.36f)
        }
        drawPath(c, color, style = Stroke(width = w * 0.07f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
