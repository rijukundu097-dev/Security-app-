package com.riju.guardian

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import java.io.File
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

/**
 * Runs the whole time protection is on. Also does the intruder photo capture itself,
 * using the camera directly inside this already-running service — no separate screen
 * or window is ever opened, so the lock screen is never disturbed.
 */
class ProtectionService : LifecycleService() {

    private var connectivityManager: ConnectivityManager? = null
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            lifecycleScope.launch(Dispatchers.IO) { EmailQueue.retryAll(applicationContext) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        connectivityManager = getSystemService(ConnectivityManager::class.java)
        connectivityManager?.registerNetworkCallback(
            NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build(),
            networkCallback
        )
        lifecycleScope.launch(Dispatchers.IO) { EmailQueue.retryAll(applicationContext) }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Protection status", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                1, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(1, notification)
        }
        if (intent?.action == ACTION_CAPTURE) {
            val eventId = intent.getLongExtra(EXTRA_EVENT_ID, -1L)
            val sendEmail = intent.getBooleanExtra(EXTRA_SEND_EMAIL, false)
            lifecycleScope.launch(Dispatchers.IO) { runCapture(eventId, sendEmail) }
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_shield)
            .setContentTitle("Guardian protection is on")
            .setContentText("Watching for wrong unlock attempts and taking a photo when one happens")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    // ---------- Capture (runs on this service's own lifecycle, no window at all) ----------

    private suspend fun runCapture(eventId: Long, sendEmail: Boolean) {
        val cameraOk = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (!cameraOk) {
            EventLogger.log(this, "system", "Photo skipped: camera permission missing")
            return
        }
        val provider = try {
            withContext(Dispatchers.Main) { getCameraProvider() }
        } catch (e: Exception) {
            EventLogger.log(this, "system", "Camera could not start: ${e.message}")
            return
        }

        val dir = File(filesDir, "evidence").apply { mkdirs() }
        var frontPath: String? = null
        var backPath: String? = null
        val errors = mutableListOf<String>()

        for ((selector, label) in listOf(
            CameraSelector.DEFAULT_FRONT_CAMERA to "front",
            CameraSelector.DEFAULT_BACK_CAMERA to "back"
        )) {
            try {
                val path = withContext(Dispatchers.Main) { shoot(provider, selector, label, dir) }
                if (label == "front") frontPath = path else backPath = path
            } catch (e: Exception) {
                errors.add("The $label photo failed: ${e.message}")
            }
        }
        withContext(Dispatchers.Main) {
            try { provider.unbindAll() } catch (e: Exception) { }
        }

        val dao = AppDatabase.get(applicationContext).eventDao()
        val hasPhoto = frontPath != null || backPath != null
        val loc = lastLocation()
        if (hasPhoto) dao.attachEvidence(eventId, frontPath, backPath, loc?.latitude, loc?.longitude)
        errors.forEach { dao.insert(SecurityEvent(type = "system", message = it)) }

        if (sendEmail && hasPhoto && Prefs.emailEnabled(applicationContext)) {
            val files = listOfNotNull(frontPath, backPath).map { File(it) }
            val body = buildString {
                append("Wrong unlock attempt on your phone at ${Date()}.\n")
                if (loc != null) {
                    append("Location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}\n")
                } else {
                    append("Location: not available.\n")
                }
                append("Photos attached (front and rear camera).")
            }
            val err = EmailQueue.sendOrQueue(applicationContext, "Guardian: wrong unlock attempt", body, files)
            dao.insert(
                SecurityEvent(
                    type = "system",
                    message = if (err == null) "Photos emailed to ${Prefs.email(applicationContext)}"
                    else "Could not email now, will retry when online"
                )
            )
        }
    }

    private suspend fun getCameraProvider(): ProcessCameraProvider =
        suspendCancellableCoroutine { cont ->
            val future = ProcessCameraProvider.getInstance(this)
            future.addListener(
                { cont.resume(future.get()) { } },
                ContextCompat.getMainExecutor(this)
            )
        }

    private suspend fun shoot(
        provider: ProcessCameraProvider,
        selector: CameraSelector,
        label: String,
        dir: File
    ): String = suspendCancellableCoroutine { cont ->
        val capture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
        try {
            provider.unbindAll()
            provider.bindToLifecycle(this, selector, capture)
        } catch (e: Exception) {
            cont.cancel(e)
            return@suspendCancellableCoroutine
        }
        val file = File(dir, "${label}_${System.currentTimeMillis()}.jpg")
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            capture.takePicture(
                ImageCapture.OutputFileOptions.Builder(file).build(),
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                        cont.resume(file.absolutePath) { }
                    }

                    override fun onError(exc: ImageCaptureException) {
                        cont.cancel(exc)
                    }
                }
            )
        }, 150)
    }

    @SuppressLint("MissingPermission")
    private fun lastLocation(): Location? {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) return null
        val lm = getSystemService(LocationManager::class.java)
        return listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        ).mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (e: Exception) { null }
        }.maxByOrNull { it.time }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { connectivityManager?.unregisterNetworkCallback(networkCallback) } catch (e: Exception) { }
    }

    companion object {
        private const val CHANNEL = "protection"
        const val ACTION_CAPTURE = "com.riju.guardian.ACTION_CAPTURE"
        const val EXTRA_EVENT_ID = "event_id"
        const val EXTRA_SEND_EMAIL = "send_email"

        fun capture(ctx: android.content.Context, eventId: Long, sendEmail: Boolean) {
            val intent = Intent(ctx, ProtectionService::class.java)
                .setAction(ACTION_CAPTURE)
                .putExtra(EXTRA_EVENT_ID, eventId)
                .putExtra(EXTRA_SEND_EMAIL, sendEmail)
            ContextCompat.startForegroundService(ctx, intent)
        }
    }
}
