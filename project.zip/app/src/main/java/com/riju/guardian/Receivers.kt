package com.riju.guardian

import android.app.admin.DeviceAdminReceiver
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        EventLogger.log(context, "system", "Device Admin enabled", goAsync())
    }

    override fun onDisabled(context: Context, intent: Intent) {
        EventLogger.log(context, "system", "Device Admin disabled", goAsync())
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        if (!Prefs.isEnabled(context)) return
        EventLogger.log(context, "intruder", "Wrong unlock attempt detected", goAsync()) { id ->
            val now = System.currentTimeMillis()
            if (now - Prefs.lastCapture(context) > 5000) {
                Prefs.setLastCapture(context, now)
                CaptureLauncher.start(context, id, requireOverlay = true)
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.isEnabled(context)) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, ProtectionService::class.java)
            )
            EventLogger.log(context, "system", "Phone restarted, protection resumed", goAsync())
        }
    }
}
