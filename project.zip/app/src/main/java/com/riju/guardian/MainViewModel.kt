package com.riju.guardian

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).eventDao()

    val events: StateFlow<List<SecurityEvent>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var protectionOn by mutableStateOf(Prefs.isEnabled(app))
        private set

    fun retryQueuedEmails() {
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) { EmailQueue.retryAll(ctx) }
    }

    fun setProtection(on: Boolean) {
        val ctx = getApplication<Application>()
        protectionOn = on
        Prefs.setEnabled(ctx, on)
        val intent = Intent(ctx, ProtectionService::class.java)
        if (on) {
            ContextCompat.startForegroundService(ctx, intent)
            EventLogger.log(ctx, "system", "Protection turned on")
        } else {
            ctx.stopService(intent)
            EventLogger.log(ctx, "system", "Protection turned off")
        }
    }

    fun deleteEvent(e: SecurityEvent) {
        viewModelScope.launch(Dispatchers.IO) {
            e.photoPath?.let { File(it).delete() }
            e.backPhotoPath?.let { File(it).delete() }
            dao.delete(e.id)
        }
    }

    fun testCapture() {
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val id = dao.insert(SecurityEvent(type = "test", message = "Test photo"))
            CaptureLauncher.start(ctx, id, requireOverlay = false, sendEmail = false)
        }
    }

    fun saveEmail(email: String, password: String, enabled: Boolean) {
        val ctx = getApplication<Application>()
        Prefs.setEmail(ctx, email)
        if (password.isNotBlank()) Prefs.setPassword(ctx, Secrets.encrypt(password))
        Prefs.setEmailEnabled(ctx, enabled)
        EventLogger.log(ctx, "system", "Email settings saved")
    }

    fun sendTestEmail() {
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val err = Mailer.send(
                ctx, "Guardian test email",
                "If you can read this, Guardian email alerts work.", emptyList()
            )
            dao.insert(
                SecurityEvent(
                    type = "system",
                    message = if (err == null) "Test email sent" else "Test email failed: $err"
                )
            )
        }
    }

    fun clearEvents() {
        viewModelScope.launch(Dispatchers.IO) {
            File(getApplication<Application>().filesDir, "evidence").deleteRecursively()
            dao.clear()
        }
    }
}
