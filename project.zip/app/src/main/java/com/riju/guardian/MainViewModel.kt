package com.riju.guardian

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).eventDao()

    val events: StateFlow<List<SecurityEvent>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var protectionOn by mutableStateOf(Prefs.isEnabled(app))
        private set

    fun setProtection(on: Boolean) {
        val ctx = getApplication<Application>()
        protectionOn = on
        Prefs.setEnabled(ctx, on)
        val intent = Intent(ctx, ProtectionService::class.java)
        if (on) {
            ContextCompat.startForegroundService(ctx, intent)
            EventLogger.log(ctx, "system", "Protection turned on")
        } else {
            ctx.stopService(intent)
            EventLogger.log(ctx, "system", "Protection turned off")
        }
    }

    fun clearEvents() {
        viewModelScope.launch { dao.clear() }
    }
}
