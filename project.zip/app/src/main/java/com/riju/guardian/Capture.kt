package com.riju.guardian

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object CaptureLauncher {
    fun start(ctx: Context, eventId: Long, requireOverlay: Boolean) {
        val cameraOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (!cameraOk) {
            EventLogger.log(ctx, "system", "Photo skipped: camera permission missing")
            return
        }
        if (requireOverlay && !Settings.canDrawOverlays(ctx)) {
            EventLogger.log(ctx, "system", "Photo skipped: 'Display over other apps' is off")
            return
        }
        val intent = Intent(ctx, CaptureActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("event_id", eventId)
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            EventLogger.log(ctx, "system", "Photo failed to start: ${e.message}")
        }
    }
}

class CaptureActivity : ComponentActivity() {
    private var eventId = -1L
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        eventId = intent.getLongExtra("event_id", -1L)

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, capture)
            } catch (e: Exception) {
                finishWith(null, "Camera could not start: ${e.message}")
                return@addListener
            }
            // short pause so exposure can settle
            Handler(Looper.getMainLooper()).postDelayed({ takePhoto(capture) }, 800)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto(capture: ImageCapture) {
        val dir = File(filesDir, "evidence").apply { mkdirs() }
        val file = File(dir, "intruder_${System.currentTimeMillis()}.jpg")
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    finishWith(file.absolutePath, null)
                }

                override fun onError(exc: ImageCaptureException) {
                    finishWith(null, "Photo failed: ${exc.message}")
                }
            }
        )
    }

    private fun finishWith(path: String?, error: String?) {
        if (done) return
        done = true
        val app = applicationContext
        val id = eventId
        val loc = lastLocation()
        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.get(app).eventDao()
            if (path != null) dao.attachEvidence(id, path, loc?.latitude, loc?.longitude)
            else if (error != null) dao.insert(SecurityEvent(type = "system", message = error))
        }
        finish()
    }

    @SuppressLint("MissingPermission")
    private fun lastLocation(): Location? {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) return null
        val lm = getSystemService(LocationManager::class.java)
        return listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        ).mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (e: Exception) { null }
        }.maxByOrNull { it.time }
    }
}
