package com.riju.guardian

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Date
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object CaptureLauncher {
    fun start(ctx: Context, eventId: Long, requireOverlay: Boolean, sendEmail: Boolean) {
        val cameraOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (!cameraOk) {
            EventLogger.log(ctx, "system", "Photo skipped: camera permission missing")
            return
        }
        if (requireOverlay && !Settings.canDrawOverlays(ctx)) {
            EventLogger.log(ctx, "system", "Photo skipped: 'Display over other apps' is off")
            return
        }
        val intent = Intent(ctx, CaptureActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("event_id", eventId)
            .putExtra("send_email", sendEmail)
        try {
            ctx.startActivity(intent)
            if (ctx is android.app.Activity) {
                ctx.overridePendingTransition(0, 0)
            }
        } catch (e: Exception) {
            EventLogger.log(ctx, "system", "Photo failed to start: ${e.message}")
        }
    }
}

class CaptureActivity : ComponentActivity() {
    private var eventId = -1L
    private var sendEmail = false
    private var done = false
    private var provider: ProcessCameraProvider? = null
    private var frontPath: String? = null
    private var backPath: String? = null
    private val errors = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
        window.setWindowAnimations(0)
        window.setDimAmount(0f)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        eventId = intent.getLongExtra("event_id", -1L)
        sendEmail = intent.getBooleanExtra("send_email", false)

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            // front camera first, then the rear camera
            shoot(CameraSelector.DEFAULT_FRONT_CAMERA, "front") {
                shoot(CameraSelector.DEFAULT_BACK_CAMERA, "back") { finishAll() }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun shoot(selector: CameraSelector, label: String, next: () -> Unit) {
        val capture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
        try {
            provider?.unbindAll()
            provider?.bindToLifecycle(this, selector, capture)
        } catch (e: Exception) {
            errors.add("The $label camera could not start: ${e.message}")
            next()
            return
        }
        // short pause so exposure can settle
        Handler(Looper.getMainLooper()).postDelayed({ takePhoto(capture, label, next) }, 150)
    }

    private fun takePhoto(capture: ImageCapture, label: String, next: () -> Unit) {
        val dir = File(filesDir, "evidence").apply { mkdirs() }
        val file = File(dir, "${label}_${System.currentTimeMillis()}.jpg")
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    if (label == "front") frontPath = file.absolutePath else backPath = file.absolutePath
                    next()
                }

                override fun onError(exc: ImageCaptureException) {
                    errors.add("The $label photo failed: ${exc.message}")
                    next()
                }
            }
        )
    }

    private fun finishAll() {
        if (done) return
        done = true
        overridePendingTransition(0, 0)
        val app = applicationContext
        val id = eventId
        val front = frontPath
        val back = backPath
        val errs = errors.toList()
        val mail = sendEmail
        val loc = lastLocation()

        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.get(app).eventDao()
            val hasPhoto = front != null || back != null
            if (hasPhoto) dao.attachEvidence(id, front, back, loc?.latitude, loc?.longitude)
            errs.forEach { dao.insert(SecurityEvent(type = "system", message = it)) }

            if (mail && hasPhoto && Prefs.emailEnabled(app)) {
                val files = listOfNotNull(front, back).map { File(it) }
                val body = buildString {
                    append("Wrong unlock attempt on your phone at ${Date()}.\n")
                    if (loc != null) {
                        append("Location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}\n")
                    } else {
                        append("Location: not available.\n")
                    }
                    append("Photos attached (front and rear camera).")
                }
                val err = EmailQueue.sendOrQueue(app, "Guardian: wrong unlock attempt", body, files)
                dao.insert(
                    SecurityEvent(
                        type = "system",
                        message = if (err == null) "Photos emailed to ${Prefs.email(app)}" else "Could not email now, will retry when online"
                    )
                )
            }
        }
        finish()
        overridePendingTransition(0, 0)
    }

    @SuppressLint("MissingPermission")
    private fun lastLocation(): Location? {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) return null
        val lm = getSystemService(LocationManager::class.java)
        return listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        ).mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (e: Exception) { null }
        }.maxByOrNull { it.time }
    }
}
