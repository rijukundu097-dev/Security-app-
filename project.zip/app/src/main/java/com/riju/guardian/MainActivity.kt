package com.riju.guardian

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GuardianTheme {
                GuardianApp(vm, tick.intValue) { tick.intValue++ }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }
}

// ---------- Theme ----------

@Composable
fun GuardianTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF7AA2FF),
            background = Color(0xFF0E1320),
            surface = Color(0xFF171E2E)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF2F5BEA),
            background = Color(0xFFF4F6FB),
            surface = Color.White
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

// ---------- Status helpers ----------

data class SetupState(
    val camera: Boolean,
    val location: Boolean,
    val notifications: Boolean,
    val admin: Boolean,
    val battery: Boolean
) {
    val allDone get() = camera && location && notifications && admin && battery
}

fun readSetup(c: Context): SetupState {
    fun granted(p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
    val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
    return SetupState(
        camera = granted(Manifest.permission.CAMERA),
        location = granted(Manifest.permission.ACCESS_FINE_LOCATION),
        notifications = Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS),
        admin = dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java)),
        battery = pm.isIgnoringBatteryOptimizations(c.packageName)
    )
}

fun batteryPercent(c: Context): Int {
    val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    return if (level >= 0 && scale > 0) level * 100 / scale else -1
}

fun openAppSettings(c: Context) {
    c.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}"))
    )
}

fun requestAdmin(c: Context) {
    val comp = ComponentName(c, AdminReceiver::class.java)
    c.startActivity(
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
            .putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Lets Guardian notice wrong unlock attempts on this phone."
            )
    )
}

fun requestBattery(c: Context) {
    try {
        c.startActivity(
            Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${c.packageName}")
            )
        )
    } catch (e: Exception) {
        openAppSettings(c)
    }
}

// ---------- Screen ----------

@Composable
fun GuardianApp(vm: MainViewModel, tick: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val events by vm.events.collectAsStateWithLifecycle()
    val setup = remember(tick) { readSetup(ctx) }
    val battery = remember(tick) { batteryPercent(ctx) }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = pad.calculateTopPadding() + 8.dp,
                bottom = pad.calculateBottomPadding() + 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column {
                    Text("Guardian", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Anti-theft protection for this phone", style = MaterialTheme.typography.bodyMedium)
                }
            }
            item { StatusCard(vm.protectionOn, setup, battery) { vm.setProtection(it) } }
            if (!setup.allDone) item { SetupCard(setup, refresh) }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Security timeline",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    if (events.isNotEmpty()) TextButton(onClick = { vm.clearEvents() }) { Text("Clear") }
                }
            }
            if (events.isEmpty()) {
                item { Text("No events yet. Wrong unlock attempts and protection changes will show up here.") }
            } else {
                items(events, key = { it.id }) { EventRow(it) }
            }
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        content = content
    )
}

@Composable
fun StatusCard(on: Boolean, s: SetupState, battery: Int, onToggle: (Boolean) -> Unit) {
    val (title, sub, color) = when {
        !on -> Triple("Protection is OFF", "Turn it on to start watching.", Color(0xFFE5484D))
        !s.admin -> Triple("Partly protected", "Allow Device Admin to detect wrong PINs.", Color(0xFFF5A524))
        else -> Triple("Protected", "Watching for wrong unlock attempts.", Color(0xFF30A46C))
    }
    Panel {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (on && s.admin) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(sub, style = MaterialTheme.typography.bodyMedium)
                }
                Switch(checked = on, onCheckedChange = onToggle)
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth()) {
                Stat("Battery", if (battery >= 0) "$battery%" else "-", Modifier.weight(1f))
                Stat("Wrong-PIN watch", if (s.admin) "On" else "Off", Modifier.weight(1f))
                Stat("Camera", if (s.camera) "Allowed" else "Not yet", Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SetupCard(s: SetupState, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh() }

    Panel {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Setup", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            SetupRow("Camera", "To photograph intruders (next phase)", s.camera) {
                permLauncher.launch(arrayOf(Manifest.permission.CAMERA))
            }
            SetupRow("Location", "To record where an event happened", s.location) {
                permLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
            SetupRow("Notifications", "To show the protection status", s.notifications) {
                if (Build.VERSION.SDK_INT >= 33) {
                    permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                }
            }
            SetupRow("Device Admin", "Detects wrong PIN attempts", s.admin) { requestAdmin(ctx) }
            SetupRow("Unrestricted battery", "Stops the phone from killing Guardian", s.battery) {
                requestBattery(ctx)
            }
            Text(
                "On iQOO/vivo also open App settings > Battery > Unrestricted, turn on Auto-start, " +
                    "and lock Guardian in the Recents screen.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = { openAppSettings(ctx) }) { Text("Open app settings") }
        }
    }
}

@Composable
fun SetupRow(title: String, desc: String, done: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        if (done) {
            Icon(Icons.Default.CheckCircle, contentDescription = "Done", tint = Color(0xFF30A46C))
        } else {
            Button(onClick = onClick) { Text("Allow") }
        }
    }
}

@Composable
fun EventRow(e: SecurityEvent) {
    val fmt = remember { SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.getDefault()) }
    val intruder = e.type == "intruder"
    Panel {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (intruder) Icons.Default.Warning else Icons.Default.Info,
                contentDescription = null,
                tint = if (intruder) Color(0xFFE5484D) else MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(e.message, fontWeight = FontWeight.SemiBold)
                Text(fmt.format(Date(e.timestamp)), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
