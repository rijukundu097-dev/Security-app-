package com.riju.guardian

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GuardianTheme {
                GuardianApp(vm, tick.intValue) { tick.intValue++ }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }
}

// ---------- Theme ----------

@Composable
fun GuardianTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF7AA2FF),
            background = Color(0xFF0E1320),
            surface = Color(0xFF171E2E)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF2F5BEA),
            background = Color(0xFFF4F6FB),
            surface = Color.White
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

// ---------- Status helpers ----------

data class SetupState(
    val camera: Boolean,
    val location: Boolean,
    val notifications: Boolean,
    val admin: Boolean,
    val battery: Boolean,
    val overlay: Boolean
) {
    val allDone get() = camera && location && notifications && admin && battery && overlay
}

fun readSetup(c: Context): SetupState {
    fun granted(p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
    val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
    return SetupState(
        camera = granted(Manifest.permission.CAMERA),
        location = granted(Manifest.permission.ACCESS_FINE_LOCATION),
        notifications = Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS),
        admin = dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java)),
        battery = pm.isIgnoringBatteryOptimizations(c.packageName),
        overlay = Settings.canDrawOverlays(c)
    )
}

fun batteryPercent(c: Context): Int {
    val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    return if (level >= 0 && scale > 0) level * 100 / scale else -1
}

fun openAppSettings(c: Context) {
    c.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}"))
    )
}

fun requestAdmin(c: Context) {
    val comp = ComponentName(c, AdminReceiver::class.java)
    c.startActivity(
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
            .putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Lets Guardian notice wrong unlock attempts on this phone."
            )
    )
}

fun requestOverlay(c: Context) {
    c.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))
    )
}

fun requestBattery(c: Context) {
    try {
        c.startActivity(
            Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${c.packageName}")
            )
        )
    } catch (e: Exception) {
        openAppSettings(c)
    }
}

// ---------- Screen ----------

@Composable
fun GuardianApp(vm: MainViewModel, tick: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val events by vm.events.collectAsStateWithLifecycle()
    val setup = remember(tick) { readSetup(ctx) }
    val battery = remember(tick) { batteryPercent(ctx) }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = pad.calculateTopPadding() + 8.dp,
                bottom = pad.calculateBottomPadding() + 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column {
                    Text("Guardian", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Anti-theft protection for this phone", style = MaterialTheme.typography.bodyMedium)
                }
            }
            item { StatusCard(vm.protectionOn, setup, battery) { vm.setProtection(it) } }
            item {
                OutlinedButton(onClick = { vm.testCapture() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Test intruder photo")
                }
            }
            if (!setup.allDone) item { SetupCard(setup, refresh) }
            item { EmailCard(vm) }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Security timeline",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    if (events.isNotEmpty()) TextButton(onClick = { vm.clearEvents() }) { Text("Clear") }
                }
            }
            if (events.isEmpty()) {
                item { Text("No events yet. Wrong unlock attempts and protection changes will show up here.") }
            } else {
                items(events, key = { it.id }) { EventRow(it) { ev -> vm.deleteEvent(ev) } }
            }
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        content = content
    )
}

@Composable
fun StatusCard(on: Boolean, s: SetupState, battery: Int, onToggle: (Boolean) -> Unit) {
    val (title, sub, color) = when {
        !on -> Triple("Protection is OFF", "Turn it on to start watching.", Color(0xFFE5484D))
        !s.admin -> Triple("Partly protected", "Allow Device Admin to detect wrong PINs.", Color(0xFFF5A524))
        else -> Triple("Protected", "Watching for wrong unlock attempts.", Color(0xFF30A46C))
    }
    Panel {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (on && s.admin) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(sub, style = MaterialTheme.typography.bodyMedium)
                }
                Switch(checked = on, onCheckedChange = onToggle)
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth()) {
                Stat("Battery", if (battery >= 0) "$battery%" else "-", Modifier.weight(1f))
                Stat("Wrong-PIN watch", if (s.admin) "On" else "Off", Modifier.weight(1f))
                Stat("Photo capture", if (s.camera && s.overlay) "Ready" else "Needs setup", Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SetupCard(s: SetupState, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh() }

    Panel {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Setup", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            SetupRow("Camera", "To photograph intruders (next phase)", s.camera) {
                permLauncher.launch(arrayOf(Manifest.permission.CAMERA))
            }
            SetupRow("Location", "To record where an event happened", s.location) {
                permLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
            SetupRow("Notifications", "To show the protection status", s.notifications) {
                if (Build.VERSION.SDK_INT >= 33) {
                    permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                }
            }
            SetupRow("Device Admin", "Detects wrong PIN attempts", s.admin) { requestAdmin(ctx) }
            SetupRow("Display over other apps", "Lets the camera open over the lock screen", s.overlay) {
                requestOverlay(ctx)
            }
            SetupRow("Unrestricted battery", "Stops the phone from killing Guardian", s.battery) {
                requestBattery(ctx)
            }
            Text(
                "On iQOO/vivo also open App settings: Battery > Unrestricted, Auto-start on, and in " +
                    "Permissions allow \"Pop-ups while running in the background\". Then lock " +
                    "Guardian in the Recents screen.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = { openAppSettings(ctx) }) { Text("Open app settings") }
        }
    }
}

@Composable
fun SetupRow(title: String, desc: String, done: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        if (done) {
            Icon(Icons.Default.CheckCircle, contentDescription = "Done", tint = Color(0xFF30A46C))
        } else {
            Button(onClick = onClick) { Text("Allow") }
        }
    }
}

@Composable
fun EventRow(e: SecurityEvent, onDelete: (SecurityEvent) -> Unit) {
    val ctx = LocalContext.current
    val fmt = remember { SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.getDefault()) }
    val intruder = e.type == "intruder"

    Panel {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (intruder) Icons.Default.Warning else Icons.Default.Info,
                    contentDescription = null,
                    tint = if (intruder) Color(0xFFE5484D) else MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(e.message, fontWeight = FontWeight.SemiBold)
                    Text(fmt.format(Date(e.timestamp)), style = MaterialTheme.typography.bodySmall)
                }
            }
            if (e.photoPath != null || e.backPhotoPath != null) {
                Row(
                    Modifier.padding(top = 12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    e.photoPath?.let { PhotoThumb(it, "Front camera", Modifier.weight(1f)) }
                    e.backPhotoPath?.let { PhotoThumb(it, "Rear camera", Modifier.weight(1f)) }
                }
            }
            if (e.latitude != null && e.longitude != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Location: %.5f, %.5f".format(e.latitude, e.longitude),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("geo:${e.latitude},${e.longitude}?q=${e.latitude},${e.longitude}"))
                        )
                    }) { Text("Open map") }
                }
            }
            Row {
                val photos = listOfNotNull(e.photoPath, e.backPhotoPath)
                if (photos.isNotEmpty()) {
                    TextButton(onClick = { sharePhotos(ctx, photos) }) { Text("Export") }
                }
                TextButton(onClick = { onDelete(e) }) { Text("Delete") }
            }
        }
    }
}

@Composable
fun PhotoThumb(path: String, label: String, modifier: Modifier = Modifier) {
    var showBig by remember { mutableStateOf(false) }
    val thumb = remember(path) { loadBitmap(path, 4) }
    Column(modifier) {
        if (thumb != null) {
            Image(
                bitmap = thumb.asImageBitmap(),
                contentDescription = label,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { showBig = true }
            )
        }
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
    if (showBig) {
        val big = remember(path) { loadBitmap(path, 2) }
        Dialog(onDismissRequest = { showBig = false }) {
            if (big != null) {
                Image(
                    bitmap = big.asImageBitmap(),
                    contentDescription = label,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { showBig = false }
                )
            }
        }
    }
}

@Composable
fun EmailCard(vm: MainViewModel) {
    val ctx = LocalContext.current
    var email by remember { mutableStateOf(Prefs.email(ctx)) }
    var pass by remember { mutableStateOf("") }
    var enabled by remember { mutableStateOf(Prefs.emailEnabled(ctx)) }
    var saved by remember { mutableStateOf(Prefs.password(ctx).isNotBlank()) }

    Panel {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Email alerts", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Sends the photos to your Gmail when a wrong PIN is entered. Create a Gmail App " +
                    "password first: Google Account > Security > 2-Step Verification > App passwords.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Your Gmail address") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it },
                label = { Text(if (saved) "App password (saved, type to replace)" else "16-letter App password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = enabled, onCheckedChange = { enabled = it })
                Spacer(Modifier.width(10.dp))
                Text("Email photos on wrong PIN")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    vm.saveEmail(email.trim(), pass.replace(" ", ""), enabled)
                    if (pass.isNotBlank()) saved = true
                    pass = ""
                }) { Text("Save") }
                OutlinedButton(onClick = { vm.sendTestEmail() }) { Text("Send test email") }
            }
        }
    }
}

fun loadBitmap(path: String, sample: Int): Bitmap? {
    try {
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeFile(path, opts) ?: return null
        val orientation = ExifInterface(path)
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bmp
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    } catch (e: Exception) {
        return null
    }
}

fun sharePhotos(c: Context, paths: List<String>) {
    val uris = ArrayList(paths.map { FileProvider.getUriForFile(c, "${c.packageName}.files", File(it)) })
    val send = Intent(Intent.ACTION_SEND_MULTIPLE)
        .setType("image/jpeg")
        .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    c.startActivity(Intent.createChooser(send, "Export photos"))
}
