package com.riju.guardian

import android.content.BroadcastReceiver
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("guardian", Context.MODE_PRIVATE)
    fun isEnabled(c: Context): Boolean = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, value: Boolean) {
        p(c).edit().putBoolean("enabled", value).apply()
    }
}

object EventLogger {
    fun log(
        context: Context,
        type: String,
        message: String,
        pending: BroadcastReceiver.PendingResult? = null
    ) {
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.get(app).eventDao().insert(SecurityEvent(type = type, message = message))
            } finally {
                pending?.finish()
            }
        }
    }
}
