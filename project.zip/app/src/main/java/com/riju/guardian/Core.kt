package com.riju.guardian

import android.content.BroadcastReceiver
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("guardian", Context.MODE_PRIVATE)
    fun isEnabled(c: Context): Boolean = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, value: Boolean) {
        p(c).edit().putBoolean("enabled", value).apply()
    }
    fun lastCapture(c: Context): Long = p(c).getLong("last_capture", 0L)
    fun setLastCapture(c: Context, t: Long) {
        p(c).edit().putLong("last_capture", t).apply()
    }
}

object EventLogger {
    fun log(
        context: Context,
        type: String,
        message: String,
        pending: BroadcastReceiver.PendingResult? = null,
        onSaved: ((Long) -> Unit)? = null
    ) {
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val id = AppDatabase.get(app).eventDao()
                    .insert(SecurityEvent(type = type, message = message))
                onSaved?.invoke(id)
            } finally {
                pending?.finish()
            }
        }
    }
}
