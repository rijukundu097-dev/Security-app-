package com.riju.guardian

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "pending_emails")
data class PendingEmail(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val body: String,
    val frontPath: String?,
    val backPath: String?,
    val createdAt: Long = System.currentTimeMillis(),
    val attempts: Int = 0
)

@Entity(tableName = "events")
data class SecurityEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val photoPath: String? = null,
    val backPhotoPath: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null
)

@Dao
interface EventDao {
    @Insert
    suspend fun insert(event: SecurityEvent): Long

    @Query("UPDATE events SET photoPath = :front, backPhotoPath = :back, latitude = :lat, longitude = :lng WHERE id = :id")
    suspend fun attachEvidence(id: Long, front: String?, back: String?, lat: Double?, lng: Double?)

    @Query("DELETE FROM events WHERE id = :id")
    suspend fun delete(id: Long)


    @Query("SELECT * FROM events ORDER BY timestamp DESC LIMIT 100")
    fun observeAll(): Flow<List<SecurityEvent>>

    @Query("DELETE FROM events")
    suspend fun clear()
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE events ADD COLUMN photoPath TEXT")
        db.execSQL("ALTER TABLE events ADD COLUMN latitude REAL")
        db.execSQL("ALTER TABLE events ADD COLUMN longitude REAL")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE events ADD COLUMN backPhotoPath TEXT")
    }
}

@Dao
interface PendingEmailDao {
    @Insert
    suspend fun insert(item: PendingEmail): Long

    @Query("SELECT * FROM pending_emails ORDER BY createdAt ASC")
    suspend fun all(): List<PendingEmail>

    @Query("DELETE FROM pending_emails WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE pending_emails SET attempts = attempts + 1 WHERE id = :id")
    suspend fun bumpAttempts(id: Long)
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS pending_emails (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "subject TEXT NOT NULL, body TEXT NOT NULL, " +
                "frontPath TEXT, backPath TEXT, " +
                "createdAt INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0)"
        )
    }
}

@Database(entities = [SecurityEvent::class, PendingEmail::class], version = 4, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao
    abstract fun pendingEmailDao(): PendingEmailDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "guardian.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build().also { instance = it }
            }
    }
}
