package com.riju.guardian

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "events")
data class SecurityEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface EventDao {
    @Insert
    suspend fun insert(event: SecurityEvent)

    @Query("SELECT * FROM events ORDER BY timestamp DESC LIMIT 100")
    fun observeAll(): Flow<List<SecurityEvent>>

    @Query("DELETE FROM events")
    suspend fun clear()
}

@Database(entities = [SecurityEvent::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "guardian.db"
                ).build().also { instance = it }
            }
    }
}
