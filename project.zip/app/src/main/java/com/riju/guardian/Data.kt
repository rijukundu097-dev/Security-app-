package com.riju.guardian

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "events")
data class SecurityEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val photoPath: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null
)

@Dao
interface EventDao {
    @Insert
    suspend fun insert(event: SecurityEvent): Long

    @Query("UPDATE events SET photoPath = :path, latitude = :lat, longitude = :lng WHERE id = :id")
    suspend fun attachEvidence(id: Long, path: String?, lat: Double?, lng: Double?)

    @Query("DELETE FROM events WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM events ORDER BY timestamp DESC LIMIT 100")
    fun observeAll(): Flow<List<SecurityEvent>>

    @Query("DELETE FROM events")
    suspend fun clear()
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE events ADD COLUMN photoPath TEXT")
        db.execSQL("ALTER TABLE events ADD COLUMN latitude REAL")
        db.execSQL("ALTER TABLE events ADD COLUMN longitude REAL")
    }
}

@Database(entities = [SecurityEvent::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "guardian.db"
                ).addMigrations(MIGRATION_1_2).build().also { instance = it }
            }
    }
}
