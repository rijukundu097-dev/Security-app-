package com.riju.guardian

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyStore
import java.util.Properties
import javax.activation.DataHandler
import javax.activation.FileDataSource
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.mail.Authenticator
import javax.mail.AuthenticationFailedException
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart

/** Encrypts the Gmail App Password with a key that never leaves the phone's Keystore. */
object Secrets {
    private const val ALIAS = "guardian_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(plain.toByteArray())
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    fun decrypt(stored: String): String {
        val all = Base64.decode(stored, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all, 0, 12))
        return String(c.doFinal(all, 12, all.size - 12))
    }
}

object EmailQueue {
    /** Tries to send now; if it fails, saves it so ProtectionService can retry when online. */
    suspend fun sendOrQueue(ctx: Context, subject: String, body: String, files: List<File>): String? {
        val err = Mailer.send(ctx, subject, body, files)
        if (err != null) {
            val front = files.getOrNull(0)?.absolutePath
            val back = files.getOrNull(1)?.absolutePath
            AppDatabase.get(ctx).pendingEmailDao().insert(
                PendingEmail(subject = subject, body = body, frontPath = front, backPath = back)
            )
        }
        return err
    }

/** Called when the phone regains internet, or when the user taps Retry. Resends anything waiting. */
    suspend fun retryAll(ctx: Context, announceIfEmpty: Boolean = false) {
        val dao = AppDatabase.get(ctx).pendingEmailDao()
        val eventDao = AppDatabase.get(ctx).eventDao()
        val items = dao.all()
        if (items.isEmpty()) {
            if (announceIfEmpty) {
                eventDao.insert(SecurityEvent(type = "system", message = "No emails waiting to send"))
            }
            return
        }
        eventDao.insert(SecurityEvent(type = "system", message = "Retrying ${items.size} queued email(s)"))
        for (item in items) {
            val files = listOfNotNull(item.frontPath, item.backPath)
                .map { File(it) }
                .filter { it.exists() }
            val err = Mailer.send(ctx, item.subject, item.body, files)
            if (err == null) {
                dao.delete(item.id)
                eventDao.insert(SecurityEvent(type = "system", message = "Queued email sent: ${item.subject}"))
            } else {
                dao.bumpAttempts(item.id)
                if (item.attempts >= 8) {
                    dao.delete(item.id)
                    eventDao.insert(SecurityEvent(type = "system", message = "Giving up on queued email: $err"))
                }
            }
        }
    }
}

object Mailer {
    /** Sends an email to yourself through Gmail. Returns null on success, or an error text. */
    fun send(ctx: Context, subject: String, body: String, files: List<File>): String? {
        val address = Prefs.email(ctx)
        val stored = Prefs.password(ctx)
        if (address.isBlank() || stored.isBlank()) return "Email is not set up yet"
        return try {
            Thread.currentThread().contextClassLoader = Mailer::class.java.classLoader
            val password = Secrets.decrypt(stored)
            val props = Properties().apply {
                put("mail.smtp.host", "smtp.gmail.com")
                put("mail.smtp.port", "465")
                put("mail.smtp.auth", "true")
                put("mail.smtp.ssl.enable", "true")
                put("mail.smtp.connectiontimeout", "15000")
                put("mail.smtp.timeout", "30000")
                put("mail.smtp.writetimeout", "30000")
            }
            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication() = PasswordAuthentication(address, password)
            })
            val message = MimeMessage(session)
            message.setFrom(InternetAddress(address))
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(address))
            message.setSubject(subject)

            val multipart = MimeMultipart()
            val text = MimeBodyPart()
            text.setText(body)
            multipart.addBodyPart(text)
            for (f in files) {
                val part = MimeBodyPart()
                part.setDataHandler(DataHandler(FileDataSource(f)))
                part.setFileName(f.name)
                multipart.addBodyPart(part)
            }
            message.setContent(multipart)
            Transport.send(message)
            null
        } catch (e: AuthenticationFailedException) {
            "Gmail rejected the login. Use an App password, not your normal password."
        } catch (e: Exception) {
            e.message ?: e.javaClass.simpleName
        }
    }
}
